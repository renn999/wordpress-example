=== easy imgur.com post images ===
Contributors: Chris McCoy
Donate link: n/a
Tags: image, embed, imgur, thumb, thumbnail
Requires at least: 2.8
Tested up to: 3.0.1
Stable tag: 1.0

== Description ==

Easy imgur.com post images plugin lets you host your images on imgur.com 
with ease.

You can add an image via the post media manager, and it will upload the 
image to the popular image host imgur.com and let you insert the image 
into your post with a thumbnail or without.

== Installation ==

1. Download and unzip the current version of the imgur.com plugin.
2. Transfer the entire imgur directory to your `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. When making a post click on the image media manager and select the imgur tab and browse and upload your photo

== Frequently Asked Questions ==

none available at this time.

== Screenshots ==

none.

== Support ==
For support contact chris@lod.com

